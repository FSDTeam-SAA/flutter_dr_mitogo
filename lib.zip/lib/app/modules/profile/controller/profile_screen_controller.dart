
import 'package:get/get.dart';

class ProfileScreenController extends GetxController {
  
}